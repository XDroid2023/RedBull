#test

answer = input("do you like redbull ?\n")
if answer =="yes":
    print("red bull gives you wings!\n")

else:
    print("then i guss you don't get your wings")
    
